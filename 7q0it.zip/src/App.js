import React, { useState, useEffect } from "react";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import schema from "./schema";
``;
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";

// import Login from "./components/login.component";
import SignUp from "./signup";
import Table from "./Table";

function App() {
  const [data, setData] = useState(null);

  useEffect(() => {
    // new Promise((resolve) => {
    //   setTimeout(() => {
    //     resolve(db);
    //   }, 2000);
    // }).then((result) => {
    //   setData(result);
    // });
    let tableData = [
      {
        Status: "18c91898-f875-4773-901f-f1b7ea4e68b7",
        Name: "testram2",
        "User Type": "test2",
        "Date Range": "11-05-21",
        Action: "Pre-Signup"
      },
      {
        Status: "ac89170c-d88c-4db6-bec3-3a27008b92c5",
        Name: "test",
        "User Type": "test10",
        "Date Range": "11-05-21",
        Action: "Pre-Signup"
      }
    ];
    setData(tableData);
  });
  return (
    <div className="container-fluid">
      <div className="row cards-container" style={{ height: "auto" }}>
        <div className="card">
          <div className="row no-gutters">
            <div
              className="col-md-6 col-6 card-text"
              style={{ alignSelf: "center", textAlign: "center" }}
            >
              In Progress
            </div>
            <div className="col-md-6 col-6">
              <div
                className="card-body"
                style={{
                  alignSelf: "center",
                  textAlign: "center",
                  backgroundColor: "#f99129"
                }}
              >
                <h5 className="card-title">5</h5>
              </div>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="row no-gutters">
            <div
              className="col-md-6 col-6 card-text"
              style={{ alignSelf: "center", textAlign: "center" }}
            >
              Open
            </div>
            <div className="col-md-6 col-6">
              <div
                className="card-body"
                style={{
                  alignSelf: "center",
                  textAlign: "center",
                  backgroundColor: "#007ACE"
                }}
              >
                <h5 className="card-title">5</h5>
              </div>
            </div>
          </div>
        </div>
        <div className="card">
          <div className="row no-gutters">
            <div
              className="col-md-6 col-6 card-text"
              style={{ alignSelf: "center", textAlign: "center" }}
            >
              Onboard
            </div>
            <div className="col-md-6 col-6">
              <div
                className="card-body"
                style={{
                  alignSelf: "center",
                  textAlign: "center",
                  backgroundColor: "#46B132"
                }}
              >
                <h5 className="card-title">5</h5>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="container datatable">
        <Table headers={Object.keys(schema)} rows={data} />
      </div>
    </div>
  );
}

export default App;
